package com.veda.browser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.net.Uri
import android.webkit.*
import android.widget.*
import android.text.InputType
import android.content.Context

class MainActivity : Activity() {
    private val purple = Color.rgb(91, 44, 150)
    private val dark = Color.rgb(24, 18, 35)
    private val prefs by lazy { getSharedPreferences("veda_browser", Context.MODE_PRIVATE) }
    private val adHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adform.net", "taboola.com",
        "outbrain.com", "adsrvr.org", "criteo.com", "scorecardresearch.com",
        "amazon-adsystem.com", "zedo.com", "popads.net", "adsterra.com",
        "exoclick.com", "hotjar.com", "connect.facebook.net"
    )
    private val tabs = mutableListOf<WebView>()
    private val history = mutableListOf<String>()
    private val bookmarks = linkedSetOf<String>()
    private var current = 0
    private lateinit var address: EditText
    private lateinit var pageHost: FrameLayout
    private lateinit var status: TextView
    private lateinit var adButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        loadSavedLists()
        buildUi()
        newTab("https://www.google.com")
    }

    private fun loadSavedLists() {
        history.addAll(prefs.getStringSet("history", emptySet())?.toList() ?: emptyList())
        bookmarks.addAll(prefs.getStringSet("bookmarks", emptySet()) ?: emptySet())
    }
    private fun saveLists() {
        prefs.edit().putStringSet("history", history.takeLast(500).toSet())
            .putStringSet("bookmarks", bookmarks.toSet()).apply()
    }
    private fun blockingEnabled() = prefs.getBoolean("ad_block_enabled", true)
    private fun setBlocking(enabled: Boolean) {
        prefs.edit().putBoolean("ad_block_enabled", enabled).apply()
        adButton.text = if (enabled) "AdBlock: ON" else "AdBlock: OFF"
        tabs.forEach { it.reload() }
        Toast.makeText(this, if (enabled) "Ad blocking enabled" else "Ad blocking disabled", Toast.LENGTH_SHORT).show()
    }

    private fun isAdUrl(raw: String?): Boolean {
        if (!blockingEnabled() || raw.isNullOrBlank()) return false
        val host = try { Uri.parse(raw).host?.lowercase() ?: return false } catch (_: Exception) { return false }
        return adHosts.any { host == it || host.endsWith(".$it") }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(dark) }
        val brand = TextView(this).apply {
            text = "✦ VEDA BROWSER"; setTextColor(Color.WHITE); textSize = 20f
            gravity = Gravity.CENTER_VERTICAL; setPadding(16, 12, 16, 8); setBackgroundColor(dark)
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 52))
        address = EditText(this).apply {
            hint = "Search or enter website"; setSingleLine(true); textSize = 16f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(14, 4, 14, 4)
            setBackgroundColor(Color.rgb(52, 39, 69))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) { navigate(text.toString()); true } else false
            }
        }
        root.addView(address, LinearLayout.LayoutParams(-1, 48).apply { setMargins(10, 0, 10, 8) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun button(label: String, action: () -> Unit): Button {
            val b = Button(this).apply { text = label; textSize = 11f; isAllCaps = false
                setTextColor(Color.WHITE); setBackgroundColor(purple); setOnClickListener { action() } }
            actions.addView(b, LinearLayout.LayoutParams(0, 46, 1f).apply { setMargins(1, 0, 1, 0) })
            return b
        }
        button("←") { if (tabs.isNotEmpty() && tabs[current].canGoBack()) tabs[current].goBack() }
        button("→") { if (tabs.isNotEmpty() && tabs[current].canGoForward()) tabs[current].goForward() }
        button("＋ Tab") { newTab("https://www.google.com") }
        button("Tabs") { showTabs() }
        button("★") { addBookmark() }
        root.addView(actions, LinearLayout.LayoutParams(-1, 48))
        val actions2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(label: String, action: () -> Unit): Button {
            val b = Button(this).apply { text = label; textSize = 10f; isAllCaps = false
                setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(65, 48, 86)); setOnClickListener { action() } }
            actions2.addView(b, LinearLayout.LayoutParams(0, 42, 1f).apply { setMargins(1, 2, 1, 2) })
            return b
        }
        small("History") { showList("History", history.reversed()) { navigate(it) } }
        small("Bookmarks") { showList("Bookmarks", bookmarks.toList()) { navigate(it) } }
        small("Home") { navigate("https://www.google.com") }
        small("Refresh") { if (tabs.isNotEmpty()) tabs[current].reload() }
        adButton = small(if (blockingEnabled()) "AdBlock: ON" else "AdBlock: OFF") { setBlocking(!blockingEnabled()) }
        root.addView(actions2, LinearLayout.LayoutParams(-1, 46))
        status = TextView(this).apply { text = "Ready"; textSize = 11f; setTextColor(Color.LTGRAY); setPadding(10, 2, 10, 2) }
        root.addView(status, LinearLayout.LayoutParams(-1, 22))
        pageHost = FrameLayout(this)
        root.addView(pageHost, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun newTab(url: String) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (isAdUrl(request.url.toString())) {
                    return WebResourceResponse("text/plain", "utf-8", 204, "Blocked by VEDA Browser", mapOf("Access-Control-Allow-Origin" to "*"), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme
                return scheme != "http" && scheme != "https"
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                address.setText(url ?: ""); status.text = "Loading…"
            }
            override fun onPageFinished(view: WebView, url: String?) {
                address.setText(url ?: "")
                if (!url.isNullOrBlank() && (history.isEmpty() || history.last() != url)) {
                    history.add(url); if (history.size > 500) history.removeAt(0); saveLists()
                }
                status.text = "Loaded"
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, progress: Int) { status.text = "Loading $progress%" }
            override fun onReceivedTitle(view: WebView, title: String?) { if (!title.isNullOrBlank()) status.text = title }
        }
        tabs.add(web); current = tabs.lastIndex
        pageHost.addView(web, FrameLayout.LayoutParams(-1, -1))
        showCurrent(); web.loadUrl(url)
    }

    private fun showCurrent() {
        tabs.forEachIndexed { i, w -> w.visibility = if (i == current) View.VISIBLE else View.GONE }
        if (tabs.isNotEmpty()) address.setText(tabs[current].url ?: "")
        status.text = "Tab ${current + 1}/${tabs.size}"
    }

    private fun navigate(input: String) {
        val s = input.trim()
        if (s.isEmpty()) return
        val url = if (s.contains(" ") || (!s.contains(".") && !s.startsWith("http"))) {
            "https://www.google.com/search?q=" + Uri.encode(s)
        } else if (!s.startsWith("http://") && !s.startsWith("https://")) "https://$s" else s
        if (tabs.isEmpty()) newTab(url) else tabs[current].loadUrl(url)
    }

    private fun showTabs() {
        if (tabs.isEmpty()) return
        val names = tabs.mapIndexed { i, w -> "${i + 1}. ${w.title ?: w.url ?: "New tab"}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Open tabs").setItems(names) { _, which -> current = which; showCurrent() }
            .setNeutralButton("New tab") { _, _ -> newTab("https://www.google.com") }
            .setNegativeButton("Close current") { _, _ ->
                if (tabs.size > 1) {
                    pageHost.removeView(tabs[current]); tabs[current].destroy(); tabs.removeAt(current)
                    current = (current - 1).coerceAtLeast(0); showCurrent()
                } else tabs[current].loadUrl("https://www.google.com")
            }.show()
    }

    private fun addBookmark() {
        val url = tabs.getOrNull(current)?.url ?: return
        bookmarks.add(url); saveLists()
        Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show()
    }
    private fun showList(title: String, items: List<String>, onPick: (String) -> Unit) {
        if (items.isEmpty()) { Toast.makeText(this, "Nothing saved yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, which -> onPick(items[which]) }
            .setNegativeButton("Close", null).show()
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && tabs.isNotEmpty()) {
            val web = tabs[current]
            if (web.canGoBack()) { web.goBack(); return true }
            if (tabs.size > 1) {
                pageHost.removeView(web); web.destroy(); tabs.removeAt(current)
                current = (current - 1).coerceAtLeast(0); showCurrent(); return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onDestroy() {
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
